import Login from "@/components/form-login";

const LoginPage = async () => {
  return (
    <div>
      <Login />
    </div>
  );
};
export default LoginPage;
