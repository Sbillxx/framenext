var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/[root-of-the-server]__7f691083._.js")
R.c("server/chunks/ssr/[root-of-the-server]__33e1b31a._.js")
R.c("server/chunks/ssr/90b6f_next_ed121a4e._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/90b6f_bdad6171._.js")
R.m(97088)
module.exports=R.m(97088).exports
