var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__7f691083._.js")
R.c("server/chunks/ssr/[root-of-the-server]__33e1b31a._.js")
R.m(53167)
module.exports=R.m(53167).exports
