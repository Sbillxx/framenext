var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/feedback/route.js")
R.c("server/chunks/[root-of-the-server]__ef4c46b8._.js")
R.c("server/chunks/[root-of-the-server]__7e72eee6._.js")
R.c("server/chunks/OneDrive_Documents_vs-code_twibonnext_framenext_8629a473._.js")
R.c("server/chunks/90b6f_next_581bd236._.js")
R.m(92203)
R.m(70753)
module.exports=R.m(70753).exports
