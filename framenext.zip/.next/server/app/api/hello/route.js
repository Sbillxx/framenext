var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/hello/route.js")
R.c("server/chunks/[root-of-the-server]__1d356b34._.js")
R.c("server/chunks/90b6f_next_581bd236._.js")
R.m(51063)
R.m(30272)
module.exports=R.m(30272).exports
