var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/users/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__f39e067c._.js")
R.c("server/chunks/90b6f_next_581bd236._.js")
R.m(18925)
R.m(82874)
module.exports=R.m(82874).exports
