var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/images/uploads/[filename]/route.js")
R.c("server/chunks/[root-of-the-server]__84667a2a._.js")
R.c("server/chunks/90b6f_next_581bd236._.js")
R.m(83324)
R.m(89051)
module.exports=R.m(89051).exports
