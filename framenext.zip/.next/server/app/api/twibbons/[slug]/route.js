var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/twibbons/[slug]/route.js")
R.c("server/chunks/[root-of-the-server]__a5414513._.js")
R.c("server/chunks/[root-of-the-server]__7e72eee6._.js")
R.c("server/chunks/OneDrive_Documents_vs-code_twibonnext_framenext_8629a473._.js")
R.c("server/chunks/90b6f_next_581bd236._.js")
R.m(42688)
R.m(66573)
module.exports=R.m(66573).exports
