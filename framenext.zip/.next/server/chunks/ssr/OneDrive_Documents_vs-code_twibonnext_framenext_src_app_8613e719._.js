module.exports=[34145,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},93897,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(34145).default,width:256,height:256}}];

//# sourceMappingURL=OneDrive_Documents_vs-code_twibonnext_framenext_src_app_8613e719._.js.map