globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/fa90805183342d5f.js",
      "static/chunks/2e0ce579ca4ecb18.js",
      "static/chunks/turbopack-11a04ee9a331b7e4.js"
    ],
    "/_error": [
      "static/chunks/1ab5e7a00bea667f.js",
      "static/chunks/2e0ce579ca4ecb18.js",
      "static/chunks/turbopack-e6da067f61cf9fef.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/0c683bef5490de5a.js",
    "static/chunks/9bb63c679bdefdae.js",
    "static/chunks/2eabf43be54237b4.js",
    "static/chunks/577cd9f641a9450e.js",
    "static/chunks/3fe47bbcdb45e585.js",
    "static/chunks/c41c8764c0481615.js",
    "static/chunks/turbopack-ae62a53a817594ea.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];