__turbopack_load_page_chunks__("/_error", [
  "static/chunks/1ab5e7a00bea667f.js",
  "static/chunks/2e0ce579ca4ecb18.js",
  "static/chunks/turbopack-e6da067f61cf9fef.js"
])
