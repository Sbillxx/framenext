__turbopack_load_page_chunks__("/_app", [
  "static/chunks/fa90805183342d5f.js",
  "static/chunks/2e0ce579ca4ecb18.js",
  "static/chunks/turbopack-11a04ee9a331b7e4.js"
])
